



/*const countDownDate = new Date('Jan 01, 2023 00:00:00');

function addDays(days) {
    var result = new Date();
    result.setDate(result.getDate() + days);
    return result;
  }
  console.log(addDays(3));
*/

    let date= new Date();
    const countDownDate= new Date(date.setDate(date.getDate()+3));
    console.log(countDownDate);

function setCountdown(countingDownTime) {

    let now = new Date();
    let timeRemaining = countingDownTime - now; // timeRemaining is time left in milliseconds!

    // Seconds
    let seconds = Math.floor(timeRemaining / 1000);
    // Minutes
    let minutes = Math.floor(timeRemaining / (1000*60));
    // Hours 
    let hours = Math.floor(timeRemaining / (1000*60*60));
    // Days
    let days = Math.floor(timeRemaining / (1000*60*60*24));


    let daysToDisplay = String(days).padStart(2,'0');

    // Subtract 24 hours for every day remaining from the hour count
    let hoursToDisplay = String(hours - (days * 24)).padStart(2, '0');
    // Subtract 60 minutes for every hour remaining from the minute count
    let minutesToDisplay = String(minutes - ( hours * 60 )).padStart(2, '0');
    // Subtract 60 seconds for every minute remaining from the seconds count
    let secondsToDisplay = String(seconds - ( minutes * 60 )).padStart(2, '0');

    // Print to DOM
    const daysEl = document.getElementById('days');
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');

    daysEl.textContent = daysToDisplay;
    hoursEl.textContent = hoursToDisplay;
    minutesEl.textContent = minutesToDisplay;
    secondsEl.textContent = secondsToDisplay;
}

setCountdown(countDownDate);

// Sets the countdown after every second:
setInterval(function() {
    setCountdown(countDownDate);
},1000);
